# AI Viral Shorts Generator

Turn long-form videos (20 min – 2+ hrs) into ready-to-post short clips (≤90s)
automatically, using **faster-whisper** for transcription and the **free Google
Gemini API** to pick the most engaging moments. 100% local processing except
for the Gemini API calls themselves.

```
Video in  ->  Transcribe  ->  Gemini picks best moments  ->  FFmpeg cuts clips  ->  clips/ + clips.json
```

---

## 1. Features

- Fully automatic — no manual scrubbing or editing.
- Free Gemini API for content understanding (no OpenAI cost).
- Local Whisper transcription (faster-whisper, with openai-whisper fallback).
- Smart timestamp validation: removes overlaps, merges near-duplicates,
  enforces min/max clip length, discards junk.
- 1080x1920 (9:16) auto-crop for Shorts/Reels/TikTok, or keep source AR.
- Auto-generated `.srt` subtitles per clip, optional burned-in captions.
- Auto thumbnail extraction per clip.
- Batch processing of an entire folder of videos.
- Resume support — re-running after a crash skips re-transcription.
- Configurable via `config.json` (no code edits needed).
- Progress bars, structured logging (console + `pipeline.log`).

**Not included in this version** (flagged as future work, see §7): face-tracking
auto-zoom, embedding-based duplicate detection, and scene-cut detection. The
JSON-based overlap/near-duplicate merge in `video_editor.py` covers the most
common cases without them.

---

## 2. Installation

### 2.1 Install FFmpeg (required, system-level)

**Windows**
```powershell
choco install ffmpeg
# or download a build from https://ffmpeg.org/download.html and add its /bin folder to PATH
```

**macOS**
```bash
brew install ffmpeg
```

**Linux (Debian/Ubuntu)**
```bash
sudo apt update && sudo apt install ffmpeg
```

Verify:
```bash
ffmpeg -version
ffprobe -version
```

### 2.2 Set up the Python project

```bash
git clone <this-repo>   # or just copy the project folder
cd viral-shorts

python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

> GPU note: `faster-whisper` will use CUDA automatically if a compatible GPU +
> CTranslate2 build is available (`whisper_device: "auto"` in config.json).
> Otherwise it falls back to CPU — slower but works everywhere.

### 2.3 Get a free Gemini API key

1. Go to https://aistudio.google.com/app/apikey
2. Create a key (free tier is sufficient for this tool).
3. Copy `.env.example` to `.env` and paste your key:

```bash
cp .env.example .env
```

```
GEMINI_API_KEY=AIzaSy...your_key_here
```

**Never commit `.env` to version control.**

---

## 3. Usage

### Interactive mode
```bash
python main.py
```
You'll be prompted:
```
Enter Video Path: C:\videos\my_podcast.mp4
Enter Output Folder: C:\videos\output
```

### Scripted single video
```bash
python main.py --video "videos/podcast.mp4" --output "output/podcast"
```

### Batch mode (process a whole folder)
```bash
python main.py --batch "videos/" --output "output/"
```
Each video gets its own subfolder under `output/<video_name>/clips/`.

### Custom config / env location
```bash
python main.py --video video.mp4 --output out --config custom_config.json --env prod.env
```

### Disable resume (force full re-transcription)
```bash
python main.py --video video.mp4 --output out --no-resume
```

### Example console output
```
=========================================================
   AI Viral Shorts Generator  (Powered by Gemini + Whisper)
=========================================================
Processing...
Extracting Audio...
Transcribing...
Analyzing using Gemini...
Creating Clips...
Done! Generated 12 clips.
Clips saved to: output/podcast/clips
Manifest: output/podcast/clips.json
```

---

## 4. Project Structure

```
project/
  main.py              # CLI entry point
  clip_generator.py    # Orchestrates the full pipeline per video
  transcriber.py        # Audio extraction + Whisper transcription + chunking
  gemini_client.py      # Gemini prompt building, API calls, JSON parsing
  video_editor.py       # Timestamp validation/merge + ffmpeg clip export + subs/thumbnails
  utils.py              # Logging, timestamp math, validation, JSON extraction
  config.py             # AppConfig dataclass, loads config.json + .env
  requirements.txt
  README.md
  .env.example
  config.json
  output/
    <video_name>/
      clips/
        clip_001.mp4
        clip_001.srt
        clip_001_thumb.jpg
        ...
      clips.json
      temp/
        transcript_cache.json   # kept for resume support
```

---

## 5. Configuration Reference (`config.json`)

| Key | Default | Description |
|---|---|---|
| `gemini_model` | `gemini-2.0-flash` | Gemini model used for analysis |
| `max_clip_seconds` | `90` | Hard cap on clip length |
| `min_clip_seconds` | `20` | Clips shorter than this are discarded |
| `merge_gap_seconds` | `1.5` | Gaps smaller than this get merged into one clip |
| `max_clips_per_video` | `20` | Top-N clips kept per video (by Gemini score) |
| `whisper_model_size` | `small` | `tiny`/`base`/`small`/`medium`/`large-v3` |
| `whisper_device` | `auto` | `auto`/`cpu`/`cuda` |
| `transcript_chunk_chars` | `12000` | Max characters per Gemini request chunk |
| `output_width`/`output_height` | `1080`/`1920` | Vertical export resolution |
| `keep_source_resolution` | `false` | Skip crop, keep original aspect ratio |
| `crf` / `preset` | `18` / `medium` | x264 quality/speed tradeoff |
| `generate_subtitles` | `true` | Write a `.srt` per clip |
| `burn_in_captions` | `false` | Also render a hardcoded-caption MP4 |
| `generate_thumbnails` | `true` | Extract a JPEG thumbnail per clip |
| `resume_supported` | `true` | Cache transcript to skip re-transcription on retry |
| `max_export_workers` | `2` | Parallel ffmpeg export threads |

---

## 6. Gemini Prompt & JSON Schema

The system prompt (see `gemini_client.py::SYSTEM_PROMPT`) instructs Gemini to
return **only** a JSON array, one object per candidate clip:

```json
[
  {
    "title": "Why Python beats Java",
    "start": "00:03:10",
    "end": "00:04:28",
    "score": 98,
    "reason": "Strong hook with practical explanation"
  }
]
```

`clips.json` (final manifest written after export) extends this with runtime
fields:

```json
[
  {
    "title": "Why Python beats Java",
    "start": 190.0,
    "end": 268.0,
    "duration": 78.0,
    "score": 98,
    "reason": "Strong hook with practical explanation",
    "filename": "clip_001.mp4"
  }
]
```

---

## 7. Known Limitations / Future Work

- No face-tracking auto-zoom for vertical crop (currently a fixed center-crop).
- No embedding-based semantic duplicate detection (heuristic overlap merge only).
- No automatic scene-cut detection to avoid cutting mid-shot.
- Gemini free-tier rate limits apply for very long videos with many transcript
  chunks; the client retries with backoff but very large batches may still be
  throttled — consider `transcript_chunk_chars` tuning for huge videos.

---

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| `FFmpeg/ffprobe not found on PATH` | Install FFmpeg (§2.1) and restart your terminal |
| `GEMINI_API_KEY is missing` | Create `.env` from `.env.example` and add your key |
| `Both faster-whisper and openai-whisper are unavailable` | `pip install faster-whisper` |
| Gemini returns empty `[]` for a chunk | Normal for filler/silence-only sections; other chunks still contribute clips |
| Out of memory on long videos | Use a smaller `whisper_model_size` (e.g. `tiny` or `base`) |
| Video corrupted / duration unreadable | Re-encode the source file or verify it opens in a media player first |
